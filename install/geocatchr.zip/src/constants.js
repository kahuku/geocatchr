export const MESSAGE_TYPES = {
  FETCH_SUMMARY: "FETCH_SUMMARY",
  DUEL_FINISHED: "DUEL_FINISHED",
  DUEL_FINISHED_RAW: "DUEL_FINISHED_RAW",
  LOBBY_PLAYER_ID: "LOBBY_PLAYER_ID",
  DAILY_SHOP_CLAIMED: "DAILY_SHOP_CLAIMED",
  LOGIN: "LOGIN",
  LOGOUT: "LOGOUT",
  CHECK_FOR_UPDATE: "CHECK_FOR_UPDATE"
};

export const STORAGE_KEYS = {
  ID_TOKEN: "id_token",
  ACCESS_TOKEN: "access_token",
  REFRESH_TOKEN: "refresh_token",
  TOKEN_TYPE: "token_type",
  EXPIRES_IN: "expires_in",
  EXPIRES_AT: "expires_at",
  PKCE_VERIFIER: "pkce_code_verifier",
  OAUTH_STATE: "oauth_state",
  UPDATE_STATUS: "updateStatus",
  PLAYER_ID: "player_id"
};
